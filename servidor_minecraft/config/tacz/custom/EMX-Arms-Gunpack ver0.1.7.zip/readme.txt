[逆境重科军备]EMX-Arms GunsPack
随性创作，技术有限。该枪械包尚在制作中，非最终版，严禁私自分发。
该武器包在tacz群内的所有测试版本仅供群内学习交流，请勿外传！
如需宣传引用，请注明本枪械包作者：SF2403（b站ID：SF2403）

注意：为了优化EMX电磁狙已经做了大量块删减，因此建模细节降低。如果想要恢复之前的模型，可以在模型文件夹emxarms\models\gun找到旧版模型：emx_pmg90_geo_old，将其替换。

武器包curseforge发布链接：
https://www.curseforge.com/minecraft/customization/tacz-emx-arms-gunpack
作者SF2403的爱发电：（可以获取公开版更新或者开发版的抢先体验）
https://afdian.net/a/SF2403

如何安装：
1.安装适合你MC版本的TacZmod本体。（mod下载下面有链接）
2.将本枪包直接放入“<游戏目录>\config\tacz\custom”即可完成安装，无需解压。
【武器包没有版本限制，全MC版本通用（前提是那个版本有TacZmod）】


问题：如何获取TacZ最新测试版/加入测试群？
在爱发电内搜索TacZ开发者：起重基喵
详见开发者给出的获取/进群方法。
测试群内可以获取最新测试版tacz、学习tacz武器包开发方法、与大佬交流、下载群友分享的自制枪包。


鸣谢：TacZ全体开发者
Mod本体链接(curseforge)：
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero

-------------------------------------------------------------------------------------------------------------
下面写给开发者：
因为EMX武器的配件属性增益计算与其他枪械包不同，为了尊重其他枪包平衡性，本包配件不会定为万用配件。
但枪包开发者可以将以下tag写入自己的枪包进行主动兼容，来安装上EMX配件。
//本包通用配件Tag：
	"#emxarms:scope",
	"#emxarms:scope_pistol",
	"#emxarms:grip",

分别为EMX瞄具、EMX手枪瞄具、EMX下挂组件


//本包通用定位点配件tag(可添加进自己的枪械包进行联动)：
	"emxarms:sight_emx_demo2",
	"emxarms:sight_emx_integer",
	"emxarms:grip_emx_double",
	"emxarms:grip_emx_assert",
	"emxarms:grip_emx_maxvalue",
	"emxarms:sight_emx_array",


以下为本包专属配件（如EMX内核收束组件等）！请自行决定是否添加。
	"emxarms:muzzle_emx_encapsulation",
	"emxarms:muzzle_emx_encapsulationse",
	"emxarms:bayonet_emx_skyhunter",
	"emxarms:bayonet_emx_skyhunterax",
	"emxarms:bayonet_emx_glowsword",